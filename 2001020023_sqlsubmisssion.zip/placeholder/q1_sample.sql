sqlite> SELECT categoryname FROM category ORDER BY categoryname;
Beverages
Condiments
Confections
Dairy Products
Grains/Cereals
Meat/Poultry
Produce
Seafood