sqlite> SELECT productname, companyname, contactname
   ...> FROM (SELECT productname, MIN(orderdate), companyname, contactname
   ...> FROM (SELECT id AS product_id, productname AS productname FROM Product WHERE Discontinued != 0) as discontinued
   ...> INNER JOIN orderdetail on productid = product_id
   ...> INNER JOIN 'order' ON 'order'.id = orderdetail.orderid
   ...> INNER JOIN customer ON customerid = customer.id
   ...> GROUP BY product_id)
   ...> ORDER BY productname ASC;
Alice Mutton|Consolidated Holdings|Elizabeth Brown
Chef Anton's Gumbo Mix|Piccolo und mehr|Georg Pipps
Guaraná Fantástica|Piccolo und mehr|Georg Pipps
Mishi Kobe Niku|Old World Delicatessen|Rene Phillips
Perth Pasties|Piccolo und mehr|Georg Pipps
Rössle Sauerkraut|Piccolo und mehr|Georg Pipps
Singaporean Hokkien Fried Mee|Vins et alcools Chevalier|Paul Henriot
Thüringer Rostbratwurst|Piccolo und mehr|Georg Pipps