sqlite> SELECT companyname, ROUND(delaycnt * 100.0 / cnt, 2) AS percent
   ...> FROM (SELECT shipvia, COUNT(*) AS cnt FROM 'order' GROUP BY shipvia) AS totalcnt
   ...> INNER JOIN (SELECT shipvia, COUNT(*) AS delaycnt FROM 'order' WHERE shippeddate > requireddate
   ...> GROUP BY shipvia) AS delaycnt ON totalcnt.shipvia = delaycnt.shipvia
   ...> INNER JOIN shipper ON totalcnt.shipvia = shipper.id
   ...> ORDER BY percent DESC;
Federal Shipping|23.61
Speedy Express|23.46
United Package|23.44