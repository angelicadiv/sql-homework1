sqlite> SELECT DISTINCT shipname, SUBSTRING(shipname, 0, INSTR(shipname, '-')) FROM 'order' WHERE shipname LIKE '%-%' ORDER BY shipname ASC;
Bottom-Dollar Markets|Bottom
Chop-suey Chinese|Chop
GROSELLA-Restaurante|GROSELLA
HILARION-Abastos|HILARION
Hungry Owl All-Night Grocers|Hungry Owl All
LILA-Supermercado|LILA
LINO-Delicateses|LINO
QUICK-Stop|QUICK
Save-a-lot Markets|Save