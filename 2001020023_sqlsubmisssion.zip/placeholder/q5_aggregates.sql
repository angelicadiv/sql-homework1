sqlite> SELECT categoryname, COUNT (*) as categorycnt, ROUND(AVG(unitprice), 2) AS avgprice, MIN(unitprice) AS minprice, MAX(unitprice) AS maxprice, SUM(unitsonorder) AS totalorder FROM product
   ...> INNER JOIN category ON categoryid = category.id
   ...> GROUP BY categoryid
   ...> HAVING categorycnt > 10
   ...> ORDER BY categoryid;
Beverages|12|37.98|4.5|263.5|60
Condiments|12|23.06|10|43.9|170
Confections|13|25.16|9.2|81|180
Seafood|12|20.68|6|62.5|120