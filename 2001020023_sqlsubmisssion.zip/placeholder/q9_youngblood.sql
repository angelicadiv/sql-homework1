sqlite> SELECT regiondescription, firstname, lastname, birthday FROM (SELECT regionid AS regid, MAX(employee.birthdate) AS birthday FROM employee INNER JOIN employeeterritory ON employee.id = employeeterritory.employeeid INNER JOIN territory ON territoryid = territory.id GROUP BY regionid)
   ...> INNER JOIN (SELECT firstname, lastname, birthdate, regionid, employeeid FROM employee INNER JOIN employeeterritory ON employee.id = employeeterritory.employeeid INNER JOIN territory ON territoryid = territory.id) ON birthdate = birthday AND regid = regionid
   ...> INNER JOIN region ON region.id = regionid
   ...> GROUP BY employeeid
   ...> ORDER BY regid;
Eastern|Steven|Buchanan|1987-03-04
Western|Michael|Suyama|1995-07-02
Northern|Anne|Dodsworth|1998-01-27
Southern|Janet|Leverling|1995-08-30